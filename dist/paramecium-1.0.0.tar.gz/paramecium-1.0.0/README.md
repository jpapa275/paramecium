# paramecium

Install by running `pip install --editable .` from this directory.

How to use? Read the help by running `csv_to_db --help`
![image](/imgs/csv_to_db_help.png "help me")
